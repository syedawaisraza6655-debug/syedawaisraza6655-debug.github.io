# ShortEarn Web V2

Updated responsive version of ShortEarn.

## Includes
- Modern responsive dashboard
- Mobile-friendly navigation
- Login/Register modal
- Google/Facebook OAuth hooks
- Wallet balance
- Daily Rs. 2 reward
- Daily spin
- Withdrawal form
- YouTube Shorts thumbnails
- Support email: syedawaisraza248@gmail.com

## Backend
The frontend expects the same API routes:
- POST /api/auth/login
- POST /api/auth/register
- GET /api/auth/google
- GET /api/auth/facebook
- GET /api/me
- GET /api/wallet
- POST /api/rewards/daily
- POST /api/rewards/spin
- POST /api/withdrawals

Set `API` in index.html to your production backend URL if frontend and backend are hosted separately.
