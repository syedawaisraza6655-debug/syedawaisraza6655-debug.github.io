# ShortEarn — Google Ready

## What is included
- index.html
- robots.txt
- sitemap.xml
- manifest.webmanifest
- privacy.html
- terms.html

## Publish
Upload the contents of this folder to a static HTTPS host. After the site has a public URL, update sitemap.xml so each `<loc>` contains the real full HTTPS domain.

Then add the site in Google Search Console, verify ownership, and submit `/sitemap.xml`.

## Important
The website UI is not itself a payment gateway. Real withdrawals require a secure production backend and your actual payment/verification process. Do not advertise guaranteed or instant earnings unless the backend really provides them.
